local function HideHUD()
    local HUD = FindFirstOf("SBZActionPhaseBaseWidget")
    if not HUD:IsValid() then error("HUD not valid\n") end

    if HUD:GetVisibility() == 0 then
        HUD:SetVisibility(2)
    else
        HUD:SetVisibility(0)
    end
end


RegisterKeyBind(Key.V, {ModifierKey.CONTROL}, HideHUD)
