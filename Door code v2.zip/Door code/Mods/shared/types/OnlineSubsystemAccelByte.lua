---@meta

---@class FAccelByteUniqueIdComposite
---@field Id FString
---@field PlatformType FString
---@field PlatformId FString
FAccelByteUniqueIdComposite = {}



---@class UAuthHandlerComponentAccelByteFactory : UHandlerComponentFactory
UAuthHandlerComponentAccelByteFactory = {}


