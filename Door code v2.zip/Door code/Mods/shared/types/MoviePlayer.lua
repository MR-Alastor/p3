---@meta

---@class UMoviePlayerSettings : UObject
---@field bWaitForMoviesToComplete boolean
---@field bMoviesAreSkippable boolean
---@field StartupMovies TArray<FString>
UMoviePlayerSettings = {}



