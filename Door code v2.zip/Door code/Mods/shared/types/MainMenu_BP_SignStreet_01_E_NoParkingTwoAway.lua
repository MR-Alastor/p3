---@meta

---@class AMainMenu_BP_SignStreet_01_E_NoParkingTwoAway_C : ABP_Tintable_Fixture_C
AMainMenu_BP_SignStreet_01_E_NoParkingTwoAway_C = {}


