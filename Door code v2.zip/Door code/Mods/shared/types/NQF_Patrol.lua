---@meta

---@class UNQF_Patrol_C : UNQF_BaseAI_C
UNQF_Patrol_C = {}


