---@meta

---@class UPD3_UIManager_C : USBZUIManager
UPD3_UIManager_C = {}


