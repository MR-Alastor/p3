---@meta

---@class UBP_DamageType_AssaultRifle_CAR4_C : USBZBulletDamageType
UBP_DamageType_AssaultRifle_CAR4_C = {}


