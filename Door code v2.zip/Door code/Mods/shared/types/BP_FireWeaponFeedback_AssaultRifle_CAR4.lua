---@meta

---@class UBP_FireWeaponFeedback_AssaultRifle_CAR4_C : USBZLocalPlayerFeedback
UBP_FireWeaponFeedback_AssaultRifle_CAR4_C = {}


