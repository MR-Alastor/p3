---@enum EPrefabricatorPivotPosition
EPrefabricatorPivotPosition = {
    ExtremeLeft = 0,
    ExtremeRight = 1,
    Center = 2,
    Selection = 3,
    EPrefabricatorPivotPosition_MAX = 4,
}

