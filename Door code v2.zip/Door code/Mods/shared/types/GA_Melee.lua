---@meta

---@class UGA_Melee_C : USBZPlayerMeleeAbility
UGA_Melee_C = {}


