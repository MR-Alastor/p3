---@meta

---@class UWBP_UI_Inventory_ItemDescription_WeaponModule_C : USBZWidgetBase
---@field Image_Background UImage
---@field WBP_UI_Inventory_ItemDescription_StatModule UWBP_UI_Inventory_ItemDescription_StatModule_C
UWBP_UI_Inventory_ItemDescription_WeaponModule_C = {}



