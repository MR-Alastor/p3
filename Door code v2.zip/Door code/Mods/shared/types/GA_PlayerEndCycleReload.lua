---@meta

---@class UGA_PlayerEndCycleReload_C : USBZPlayerEndCycleRangedWeaponAbility
UGA_PlayerEndCycleReload_C = {}


