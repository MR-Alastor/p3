---@meta

---@class UWBP_UI_HUD_Shoutout_C : USBZShoutoutWidget
UWBP_UI_HUD_Shoutout_C = {}


