---@meta

---@class UBP_Action_Surrender_C : USBZAIAction_Surrender
UBP_Action_Surrender_C = {}


