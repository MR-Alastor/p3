---@meta

---@class UWBP_Settings_HelperPanel_ColorBlindPreview_C : USBZSettingHelperPanel
---@field UberGraphFrame FPointerToUberGraphFrame
---@field Image_1 UImage
---@field Ishihara_0 UImage
---@field Ishihara_1 UImage
---@field Ishihara_2 UImage
---@field Ishihara_3 UImage
---@field Ishihara_4 UImage
---@field Ishihara_5 UImage
UWBP_Settings_HelperPanel_ColorBlindPreview_C = {}

---@param IsDesignTime boolean
function UWBP_Settings_HelperPanel_ColorBlindPreview_C:PreConstruct(IsDesignTime) end
function UWBP_Settings_HelperPanel_ColorBlindPreview_C:Construct() end
function UWBP_Settings_HelperPanel_ColorBlindPreview_C:RefreshPanelState() end
---@param EntryPoint int32
function UWBP_Settings_HelperPanel_ColorBlindPreview_C:ExecuteUbergraph_WBP_Settings_HelperPanel_ColorBlindPreview(EntryPoint) end


