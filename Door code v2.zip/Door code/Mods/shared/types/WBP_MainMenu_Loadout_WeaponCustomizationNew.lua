---@meta

---@class UWBP_MainMenu_Loadout_WeaponCustomizationNew_C : USBZMainMenuLoadoutWeaponModCategoryWidget
---@field UberGraphFrame FPointerToUberGraphFrame
---@field Image_StatsBackground UImage
---@field Image_WeaponBackground UImage
---@field WBP_UI_WeaponSlotDisplayPanel UWBP_UI_WeaponSlotDisplayPanel_C
---@field WBP_UI_Widget_WeaponStats UWBP_UI_Widget_WeaponStats_C
---@field Widget_WeaponDescription UWBP_UI_Inventory_ItemDescription_C
---@field Widget_WeaponProgressionDisplay UWBP_UI_WeaponProgressionWidget_C
---@field FocusedButton USBZMenuButton
UWBP_MainMenu_Loadout_WeaponCustomizationNew_C = {}

---@param PreviousValue FName
function UWBP_MainMenu_Loadout_WeaponCustomizationNew_C:OnGainedStackFocused(PreviousValue) end
function UWBP_MainMenu_Loadout_WeaponCustomizationNew_C:OnLostStackFocused() end
---@param InActionInput FName
function UWBP_MainMenu_Loadout_WeaponCustomizationNew_C:OnControlsReferenceClicked(InActionInput) end
---@param InButton USBZMenuButton
---@param bIsFocused boolean
function UWBP_MainMenu_Loadout_WeaponCustomizationNew_C:OnCategoryButtonFocused(InButton, bIsFocused) end
function UWBP_MainMenu_Loadout_WeaponCustomizationNew_C:OnBackPressed() end
---@param EntryPoint int32
function UWBP_MainMenu_Loadout_WeaponCustomizationNew_C:ExecuteUbergraph_WBP_MainMenu_Loadout_WeaponCustomizationNew(EntryPoint) end


