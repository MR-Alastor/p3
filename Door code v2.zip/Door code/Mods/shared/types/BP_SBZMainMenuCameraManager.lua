---@meta

---@class ABP_SBZMainMenuCameraManager_C : ASBZMainMenuCameraManager
---@field DefaultSceneRoot USceneComponent
ABP_SBZMainMenuCameraManager_C = {}



