---@meta

---@class ABP_MainMenu_ElectricBox_01_C_Emissive_Red_C : ABP_Master_Light_Fixture_C
ABP_MainMenu_ElectricBox_01_C_Emissive_Red_C = {}


