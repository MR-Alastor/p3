---@meta

---@class UWBP_UI_Inventory_ControlsReference_C : USBZWidgetBase
---@field VerticalBox_ControlList UVerticalBox
---@field VerticalBox_Widget UVerticalBox
UWBP_UI_Inventory_ControlsReference_C = {}

---@param InControlsReference FSBZControlsReference
function UWBP_UI_Inventory_ControlsReference_C:InitControlsReference(InControlsReference) end


