---@meta

---@class UWBP_UI_KeyItemContainer_C : UPD3KeyItemContainer
UWBP_UI_KeyItemContainer_C = {}


