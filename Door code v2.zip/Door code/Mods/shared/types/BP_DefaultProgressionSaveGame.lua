---@meta

---@class UBP_DefaultProgressionSaveGame_C : USBZProgressionSaveGame
UBP_DefaultProgressionSaveGame_C = {}


