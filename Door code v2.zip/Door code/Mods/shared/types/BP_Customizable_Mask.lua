---@meta

---@class ABP_Customizable_Mask_C : ASBZMask
ABP_Customizable_Mask_C = {}


