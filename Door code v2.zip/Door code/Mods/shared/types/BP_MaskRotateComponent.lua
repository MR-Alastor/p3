---@meta

---@class UBP_MaskRotateComponent_C : USBZCustomizationRotateComponent
UBP_MaskRotateComponent_C = {}


