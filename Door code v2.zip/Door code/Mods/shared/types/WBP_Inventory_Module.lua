---@meta

---@class UWBP_Inventory_Module_C : USBZMainMenuCosmeticPanel
---@field Button UButton
---@field Button_1 UButton
---@field Button_150 UButton
---@field ScrollBox_ButtonContainer UScrollBox
UWBP_Inventory_Module_C = {}



