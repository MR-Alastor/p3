---@meta

---@class UWBP_UI_ActionControlReference_C : USBZControlsReferenceActionWidget
---@field Image_Background UImage
UWBP_UI_ActionControlReference_C = {}



