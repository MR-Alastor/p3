---@meta

---@class UBP_Order_ScriptedLifeAction_C : USBZAIOrder_LifeAction
UBP_Order_ScriptedLifeAction_C = {}


