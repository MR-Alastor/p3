---@meta

---@class UBP_WeaponRotateComponent_C : USBZCustomizationRotateComponent
UBP_WeaponRotateComponent_C = {}


