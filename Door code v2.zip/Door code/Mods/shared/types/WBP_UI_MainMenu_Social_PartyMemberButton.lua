---@meta

---@class UWBP_UI_MainMenu_Social_PartyMemberButton_C : USBZSocialPartyMemberButton
---@field UberGraphFrame FPointerToUberGraphFrame
---@field Join UWidgetAnimation
---@field Icon_Nebula UImage
---@field Icon_Platform UImage
---@field Icon_Status UImage
---@field Image_Background UImage
---@field Image_BorderButton UImage
---@field Text_LP UTextBlock
---@field Text_LP_1 UTextBlock
---@field Text_LP_2 UTextBlock
---@field Text_PlayerName_Nebula UTextBlock
---@field Text_PlayerName_Platform UTextBlock
---@field Text_PlayerStatus UTextBlock
---@field Text_RP UTextBlock
---@field Text_RP_1 UTextBlock
---@field Text_RP_2 UTextBlock
UWBP_UI_MainMenu_Social_PartyMemberButton_C = {}

---@param bIsFocused boolean
function UWBP_UI_MainMenu_Social_PartyMemberButton_C:OnFocused(bIsFocused) end
---@param bIsHovered boolean
function UWBP_UI_MainMenu_Social_PartyMemberButton_C:OnHovered(bIsHovered) end
---@param IsDesignTime boolean
function UWBP_UI_MainMenu_Social_PartyMemberButton_C:PreConstruct(IsDesignTime) end
---@param bInIsHovered boolean
function UWBP_UI_MainMenu_Social_PartyMemberButton_C:ButtonHoveredChanged(bInIsHovered) end
---@param bInHasFocus boolean
function UWBP_UI_MainMenu_Social_PartyMemberButton_C:ButtonFocusedChanged(bInHasFocus) end
function UWBP_UI_MainMenu_Social_PartyMemberButton_C:OnReadyToDisplayMember() end
function UWBP_UI_MainMenu_Social_PartyMemberButton_C:OnAcceptInviteAction() end
function UWBP_UI_MainMenu_Social_PartyMemberButton_C:OnRejectInviteAction() end
---@param EntryPoint int32
function UWBP_UI_MainMenu_Social_PartyMemberButton_C:ExecuteUbergraph_WBP_UI_MainMenu_Social_PartyMemberButton(EntryPoint) end


