---@meta

---@class FNetAnalyticsDataConfig
---@field DataName FName
---@field bEnabled boolean
FNetAnalyticsDataConfig = {}



---@class UNetAnalyticsAggregatorConfig : UObject
---@field NetAnalyticsData TArray<FNetAnalyticsDataConfig>
UNetAnalyticsAggregatorConfig = {}



