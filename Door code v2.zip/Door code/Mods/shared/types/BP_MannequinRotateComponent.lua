---@meta

---@class UBP_MannequinRotateComponent_C : USBZCustomizationRotateComponent
UBP_MannequinRotateComponent_C = {}


