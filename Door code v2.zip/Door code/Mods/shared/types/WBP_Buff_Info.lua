---@meta

---@class UWBP_Buff_Info_C : UUserWidget
---@field Image_143 UImage
---@field Image_BorderBottom_1 UImage
---@field Image_BorderLeft_1 UImage
---@field Image_BorderRight_1 UImage
---@field Image_BorderTop_1 UImage
---@field RegularBorder UOverlay
UWBP_Buff_Info_C = {}



