---@meta

---@class FKey
---@field KeyName FName
FKey = {}



---@class UInputCoreTypes : UObject
UInputCoreTypes = {}


