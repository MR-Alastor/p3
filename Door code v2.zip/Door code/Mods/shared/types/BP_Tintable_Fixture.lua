---@meta

---@class ABP_Tintable_Fixture_C : AActor
---@field StaticMesh UStaticMeshComponent
---@field DefaultSceneRoot USceneComponent
---@field tint FLinearColor
---@field Secondary_tint FLinearColor
---@field ['Roughness Text'] float
---@field ['Metallic Text'] float
ABP_Tintable_Fixture_C = {}

function ABP_Tintable_Fixture_C:UserConstructionScript() end


