---@meta

---@class ABP_MainMenu_Van_01_C : AStaticMeshActor
---@field UberGraphFrame FPointerToUberGraphFrame
ABP_MainMenu_Van_01_C = {}

function ABP_MainMenu_Van_01_C:ReceiveBeginPlay() end
---@param EntryPoint int32
function ABP_MainMenu_Van_01_C:ExecuteUbergraph_BP_MainMenu_Van_01(EntryPoint) end


