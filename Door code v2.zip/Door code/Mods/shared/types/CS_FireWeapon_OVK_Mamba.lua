---@meta

---@class UCS_FireWeapon_OVK_Mamba_C : UMatineeCameraShake
UCS_FireWeapon_OVK_Mamba_C = {}


