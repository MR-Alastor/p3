---@meta

---@class UGA_FireProjectile_C : USBZPlayerFireRangedWeaponProjectileAbility
UGA_FireProjectile_C = {}


