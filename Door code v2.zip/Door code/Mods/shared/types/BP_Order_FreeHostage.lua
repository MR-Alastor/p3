---@meta

---@class UBP_Order_FreeHostage_C : USBZAIOrder_FreeHostage
UBP_Order_FreeHostage_C = {}


