---@meta

---@class UGA_CuttingTool_C : USBZCuttingToolAbility
UGA_CuttingTool_C = {}


