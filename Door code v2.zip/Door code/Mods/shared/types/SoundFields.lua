---@meta

---@class UAmbisonicsEncodingSettings : USoundfieldEncodingSettingsBase
---@field AmbisonicsOrder int32
UAmbisonicsEncodingSettings = {}



