---@meta

---@class UBP_RoomStatus_Feedback_C : USBZLocalPlayerFeedback
UBP_RoomStatus_Feedback_C = {}


