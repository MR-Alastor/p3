---@meta

---@class UWBP_HUD_CharacterEffectsWidget_C : USBZCharacterEffectContainer
UWBP_HUD_CharacterEffectsWidget_C = {}


