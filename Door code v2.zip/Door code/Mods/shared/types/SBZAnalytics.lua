---@meta

---@class USBZAccelByteAnalyticsProvider : USBZAnalyticsProvider
USBZAccelByteAnalyticsProvider = {}


---@class USBZAnalyticsProvider : UObject
USBZAnalyticsProvider = {}


---@class USBZFileAnalyticsProvider : USBZAnalyticsProvider
USBZFileAnalyticsProvider = {}


---@class USBZMockAnalyticsProvider : USBZAnalyticsProvider
USBZMockAnalyticsProvider = {}


