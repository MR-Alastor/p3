---@meta

---@class UWBP_UI_Inventory_LoadoutSkillsButton_C : USBZMenuButton
---@field UberGraphFrame FPointerToUberGraphFrame
---@field Image_Background UImage
---@field Image_BorderBottom UImage
---@field Image_BorderLeft UImage
---@field Image_BorderRight UImage
---@field Image_BorderTop UImage
---@field Image_SkillPointsRemaining UImage
---@field Overlay_Border UOverlay
---@field Overlay_Button UOverlay
---@field Text_Header UTextBlock
---@field Text_SkillsWarning UTextBlock
---@field Widget_SkillsIcon UWBP_InventoryBaseData_Icon_C
---@field Widget_SkillsIcon_1 UWBP_InventoryBaseData_Icon_C
---@field Widget_SkillsIcon_2 UWBP_InventoryBaseData_Icon_C
---@field Widget_SkillsIcon_3 UWBP_InventoryBaseData_Icon_C
---@field ButtonFocusedEvent FWBP_UI_Inventory_LoadoutSkillsButton_CButtonFocusedEvent
---@field RT_SkillPointsRemaining boolean
UWBP_UI_Inventory_LoadoutSkillsButton_C = {}

---@param SkillPointsRemaining int32
function UWBP_UI_Inventory_LoadoutSkillsButton_C:InitializeSkillPointsVisual(SkillPointsRemaining) end
function UWBP_UI_Inventory_LoadoutSkillsButton_C:RefreshVisuals() end
---@param InSkillList TArray<USBZSkillData>
function UWBP_UI_Inventory_LoadoutSkillsButton_C:InitializeSkills(InSkillList) end
---@param bIsFocused boolean
function UWBP_UI_Inventory_LoadoutSkillsButton_C:OnFocused(bIsFocused) end
---@param bIsHovered boolean
function UWBP_UI_Inventory_LoadoutSkillsButton_C:OnHover(bIsHovered) end
---@param bInHasFocus boolean
function UWBP_UI_Inventory_LoadoutSkillsButton_C:ButtonFocusedChanged(bInHasFocus) end
---@param bInIsHovered boolean
function UWBP_UI_Inventory_LoadoutSkillsButton_C:ButtonHoveredChanged(bInIsHovered) end
---@param IsDesignTime boolean
function UWBP_UI_Inventory_LoadoutSkillsButton_C:PreConstruct(IsDesignTime) end
function UWBP_UI_Inventory_LoadoutSkillsButton_C:OnInitialized() end
---@param EntryPoint int32
function UWBP_UI_Inventory_LoadoutSkillsButton_C:ExecuteUbergraph_WBP_UI_Inventory_LoadoutSkillsButton(EntryPoint) end
---@param FocusedButton UObject
function UWBP_UI_Inventory_LoadoutSkillsButton_C:ButtonFocusedEvent__DelegateSignature(FocusedButton) end


