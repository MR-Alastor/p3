---@meta

---@class ABP_CustomizationManager_C : ASBZCustomizationManager
---@field DefaultSceneRoot USceneComponent
ABP_CustomizationManager_C = {}



