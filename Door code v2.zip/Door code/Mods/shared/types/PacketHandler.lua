---@meta

---@class UHandlerComponentFactory : UObject
UHandlerComponentFactory = {}


---@class UPacketHandlerProfileConfig : UObject
---@field Components TArray<FString>
UPacketHandlerProfileConfig = {}



