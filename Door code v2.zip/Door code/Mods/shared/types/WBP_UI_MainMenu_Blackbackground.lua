---@meta

---@class UWBP_UI_MainMenu_Blackbackground_C : USBZWidgetBase
---@field UberGraphFrame FPointerToUberGraphFrame
---@field LoadingAnimation UWidgetAnimation
---@field Image_Background UImage
---@field ProgressBar_Loading UProgressBar
UWBP_UI_MainMenu_Blackbackground_C = {}

function UWBP_UI_MainMenu_Blackbackground_C:OnInitialized() end
---@param EntryPoint int32
function UWBP_UI_MainMenu_Blackbackground_C:ExecuteUbergraph_WBP_UI_MainMenu_Blackbackground(EntryPoint) end


