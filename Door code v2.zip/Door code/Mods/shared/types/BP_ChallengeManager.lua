---@meta

---@class UBP_ChallengeManager_C : USBZChallengeManager
UBP_ChallengeManager_C = {}


