---@meta

---@class UWBP_UI_MainMenu_QuickplayPopUp_C : USBZMainMenuQuickMatch
---@field UberGraphFrame FPointerToUberGraphFrame
---@field PopUp_Anim UWidgetAnimation
---@field Background UImage
---@field Button_Cancel UWBP_UI_TextButton_C
---@field Button_Ready UWBP_UI_TextButton_C
---@field Description_Difficulty UTextBlock
---@field QuickplayPopUp_Anim UImage
---@field TextBlock_Difficulty UTextBlock
---@field WBP_UI_DifficultySelectorWidget_02 UWBP_UI_DifficultySelectorWidget_02_C
---@field ['Difficulty Desc'] TMap<ESBZDifficulty, FText>
---@field ['RT Difficulty'] ESBZDifficulty
UWBP_UI_MainMenu_QuickplayPopUp_C = {}

---@param ActionName FName
function UWBP_UI_MainMenu_QuickplayPopUp_C:OnControlsReferenceClicked(ActionName) end
---@param InDifficulty ESBZDifficulty
UWBP_UI_MainMenu_QuickplayPopUp_C['Set Difficulty'] = function(InDifficulty) end
---@param NewParam ESBZDifficulty
UWBP_UI_MainMenu_QuickplayPopUp_C['Update Difficulty Visuals'] = function(NewParam) end
---@param Button USBZMenuButton
function UWBP_UI_MainMenu_QuickplayPopUp_C:BndEvt__WBP_UI_MainMenu_QuickplayPopUp_Button_Ready_K2Node_ComponentBoundEvent_0_OnMenuButtonSelected__DelegateSignature(Button) end
---@param NewIndex int32
function UWBP_UI_MainMenu_QuickplayPopUp_C:BndEvt__WBP_UI_MainMenu_QuickplayPopUp_WBP_UI_DifficultySelectorWidget_02_K2Node_ComponentBoundEvent_1_SBZOnSelectorOptionChanged__DelegateSignature(NewIndex) end
function UWBP_UI_MainMenu_QuickplayPopUp_C:OnInitialized() end
---@param PreviousValue FName
function UWBP_UI_MainMenu_QuickplayPopUp_C:OnGainedStackFocused(PreviousValue) end
function UWBP_UI_MainMenu_QuickplayPopUp_C:OnLostStackFocused() end
---@param Button USBZMenuButton
---@param bIsEnabled boolean
function UWBP_UI_MainMenu_QuickplayPopUp_C:BndEvt__WBP_UI_MainMenu_QuickplayPopUp_WBP_UI_DifficultySelectorWidget_02_K2Node_ComponentBoundEvent_2_OnMenuButtonStateChanged__DelegateSignature(Button, bIsEnabled) end
---@param Button USBZMenuButton
function UWBP_UI_MainMenu_QuickplayPopUp_C:BndEvt__WBP_UI_MainMenu_QuickplayPopUp_Button_Cancel_K2Node_ComponentBoundEvent_3_OnMenuButtonSelected__DelegateSignature(Button) end
---@param EntryPoint int32
function UWBP_UI_MainMenu_QuickplayPopUp_C:ExecuteUbergraph_WBP_UI_MainMenu_QuickplayPopUp(EntryPoint) end


