---@meta

---@class UGA_PlaceCuttingTool_C : USBZPlaceCuttableToolAbility
UGA_PlaceCuttingTool_C = {}


