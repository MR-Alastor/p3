---@meta

---@class UBP_Order_ReleasedHostage_C : USBZAIOrder_ReleaseHostage
UBP_Order_ReleasedHostage_C = {}


