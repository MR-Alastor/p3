---@meta

---@class UGauntletTestController : UObject
UGauntletTestController = {}


---@class UGauntletTestControllerBootTest : UGauntletTestController
UGauntletTestControllerBootTest = {}


---@class UGauntletTestControllerErrorTest : UGauntletTestController
UGauntletTestControllerErrorTest = {}


