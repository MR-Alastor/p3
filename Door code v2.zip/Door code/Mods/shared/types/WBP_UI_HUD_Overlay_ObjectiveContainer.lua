---@meta

---@class UWBP_UI_HUD_Overlay_ObjectiveContainer_C : USBZObjectiveContainerWidget
UWBP_UI_HUD_Overlay_ObjectiveContainer_C = {}


