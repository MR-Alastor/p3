---@enum EQuatSwizzleAxisB
EQuatSwizzleAxisB = {
    X = 0,
    Y = 1,
    Z = 2,
    W = 3,
    MinusX = 4,
    MinusY = 5,
    MinusZ = 6,
    MinusW = 7,
    EQuatSwizzleAxisB_MAX = 8,
}

