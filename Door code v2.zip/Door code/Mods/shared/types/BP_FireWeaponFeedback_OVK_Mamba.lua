---@meta

---@class UBP_FireWeaponFeedback_OVK_Mamba_C : USBZLocalPlayerFeedback
UBP_FireWeaponFeedback_OVK_Mamba_C = {}


