---@meta

---@class UWBP_UI_Inventory_Action_C : USBZControlsReferenceWidget
---@field HorizontalBox_ActionList UHorizontalBox
---@field Text_ActionName UTextBlock
UWBP_UI_Inventory_Action_C = {}

---@param InActionControlReference FSBZActionControlReference
function UWBP_UI_Inventory_Action_C:InitActionControlReference(InActionControlReference) end


