---@meta

---@class UWBP_UI_MainMenu_ControlsReference_C : USBZControlsReferenceWidget
---@field UberGraphFrame FPointerToUberGraphFrame
UWBP_UI_MainMenu_ControlsReference_C = {}

function UWBP_UI_MainMenu_ControlsReference_C:HideControlsReference() end
---@param InControlsReference FSBZControlsReference
function UWBP_UI_MainMenu_ControlsReference_C:DisplayControlsReference(InControlsReference) end
---@param EntryPoint int32
function UWBP_UI_MainMenu_ControlsReference_C:ExecuteUbergraph_WBP_UI_MainMenu_ControlsReference(EntryPoint) end


