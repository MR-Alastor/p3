---@meta

---@class ULightPropagationVolumeBlendable : UObject
---@field Settings FLightPropagationVolumeSettings
---@field BlendWeight float
ULightPropagationVolumeBlendable = {}



