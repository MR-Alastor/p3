---@meta

---@class UDT_Throwable_FragGrenade_C : USBZGrenadeDamageType
UDT_Throwable_FragGrenade_C = {}


