---@meta

---@class UGE_BallisticVest_C : UGameplayEffect
UGE_BallisticVest_C = {}


