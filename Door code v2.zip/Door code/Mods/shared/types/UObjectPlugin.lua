---@meta

---@class FMyPluginStruct
---@field TestString FString
FMyPluginStruct = {}



---@class UMyPluginObject : UObject
---@field MyStruct FMyPluginStruct
UMyPluginObject = {}



