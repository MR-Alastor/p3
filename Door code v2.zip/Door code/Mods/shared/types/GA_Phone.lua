---@meta

---@class UGA_Phone_C : USBZPhoneToolAbility
UGA_Phone_C = {}


