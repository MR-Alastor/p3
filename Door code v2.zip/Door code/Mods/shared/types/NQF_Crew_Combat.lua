---@meta

---@class UNQF_Crew_Combat_C : UNavigationQueryFilter
UNQF_Crew_Combat_C = {}


