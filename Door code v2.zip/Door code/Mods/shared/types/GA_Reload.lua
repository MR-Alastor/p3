---@meta

---@class UGA_Reload_C : USBZPlayerReloadRangedWeaponAbility
UGA_Reload_C = {}


