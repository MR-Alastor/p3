---@meta

---@class FJsonObjectWrapper
---@field JsonString FString
FJsonObjectWrapper = {}



---@class UJsonUtilitiesDummyObject : UObject
UJsonUtilitiesDummyObject = {}


