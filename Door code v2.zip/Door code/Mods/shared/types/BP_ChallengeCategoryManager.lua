---@meta

---@class UBP_ChallengeCategoryManager_C : USBZChallengeCategoryManager
UBP_ChallengeCategoryManager_C = {}


