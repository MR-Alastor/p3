---@meta

---@class UCS_FragGrenade_C : UMatineeCameraShake
UCS_FragGrenade_C = {}


