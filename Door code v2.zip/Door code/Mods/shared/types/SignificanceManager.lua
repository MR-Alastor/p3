---@meta

---@class USignificanceManager : UObject
---@field SignificanceManagerClassName FSoftClassPath
USignificanceManager = {}



