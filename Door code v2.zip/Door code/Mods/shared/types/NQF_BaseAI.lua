---@meta

---@class UNQF_BaseAI_C : UNavigationQueryFilter
UNQF_BaseAI_C = {}


