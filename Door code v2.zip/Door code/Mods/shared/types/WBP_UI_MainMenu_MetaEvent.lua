---@meta

---@class UWBP_UI_MainMenu_MetaEvent_C : UUserWidget
---@field UberGraphFrame FPointerToUberGraphFrame
---@field Text_MetaEventDescription UTextBlock
UWBP_UI_MainMenu_MetaEvent_C = {}

function UWBP_UI_MainMenu_MetaEvent_C:Construct() end
---@param EntryPoint int32
function UWBP_UI_MainMenu_MetaEvent_C:ExecuteUbergraph_WBP_UI_MainMenu_MetaEvent(EntryPoint) end


