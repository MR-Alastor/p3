---@meta

---@class UGA_PlayerTarget_C : USBZPlayerTargetAbility
UGA_PlayerTarget_C = {}


