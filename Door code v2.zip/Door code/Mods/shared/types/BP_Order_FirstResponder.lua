---@meta

---@class UBP_Order_FirstResponder_C : USBZAIOrder_FirstResponder
UBP_Order_FirstResponder_C = {}


