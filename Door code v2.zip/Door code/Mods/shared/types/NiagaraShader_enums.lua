---@enum FNiagaraCompileEventSeverity
FNiagaraCompileEventSeverity = {
    Log = 0,
    Warning = 1,
    Error = 2,
    FNiagaraCompileEventSeverity_MAX = 3,
}

