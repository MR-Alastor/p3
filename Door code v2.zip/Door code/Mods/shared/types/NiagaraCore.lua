---@meta

---@class FNiagaraCompileHash
---@field DataHash TArray<uint8>
FNiagaraCompileHash = {}



---@class UNiagaraDataInterfaceBase : UNiagaraMergeable
UNiagaraDataInterfaceBase = {}


---@class UNiagaraMergeable : UObject
UNiagaraMergeable = {}


