---@meta

---@class UAvfMediaSettings : UObject
---@field NativeAudioOut boolean
UAvfMediaSettings = {}



