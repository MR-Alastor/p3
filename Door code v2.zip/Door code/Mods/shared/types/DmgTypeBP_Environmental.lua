---@meta

---@class UDmgTypeBP_Environmental_C : UDamageType
UDmgTypeBP_Environmental_C = {}


