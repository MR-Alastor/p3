---@meta

---@class UIpConnectionAccelByte : UIpConnection
UIpConnectionAccelByte = {}


---@class UIpNetDriverAccelByte : UIpNetDriver
UIpNetDriverAccelByte = {}


