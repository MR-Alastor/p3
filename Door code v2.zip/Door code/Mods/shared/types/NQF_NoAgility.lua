---@meta

---@class UNQF_NoAgility_C : UNavigationQueryFilter
UNQF_NoAgility_C = {}


