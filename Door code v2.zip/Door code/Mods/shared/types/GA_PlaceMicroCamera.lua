---@meta

---@class UGA_PlaceMicroCamera_C : USBZPlaceMicroCameraAbility
UGA_PlaceMicroCamera_C = {}


