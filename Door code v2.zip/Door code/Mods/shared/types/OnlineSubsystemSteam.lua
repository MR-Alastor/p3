---@meta

---@class USteamAuthComponentModuleInterface : UHandlerComponentFactory
USteamAuthComponentModuleInterface = {}


---@class USteamNetConnection : UIpConnection
---@field bIsPassthrough boolean
USteamNetConnection = {}



---@class USteamNetDriver : UIpNetDriver
USteamNetDriver = {}


