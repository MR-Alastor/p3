---@enum EFiniteStateMachineStateEvent
EFiniteStateMachineStateEvent = {
    ENTER = 0,
    EXIT = 1,
    EFiniteStateMachineStateEvent_MAX = 2,
}

