---@meta

---@class UImgMediaPlaybackComponent : UActorComponent
---@field Width float
---@field LODBias float
UImgMediaPlaybackComponent = {}



