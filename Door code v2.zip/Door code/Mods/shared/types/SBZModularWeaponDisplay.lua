---@meta

---@class ASBZModularWeaponDisplay_C : ASBZModularWeaponDisplay
---@field Cube UStaticMeshComponent
ASBZModularWeaponDisplay_C = {}



