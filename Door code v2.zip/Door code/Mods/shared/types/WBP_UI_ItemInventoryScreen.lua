---@meta

---@class UWBP_UI_ItemInventoryScreen_C : USBZMainMenuItemInventoryScreen
---@field UberGraphFrame FPointerToUberGraphFrame
---@field Image_174 UImage
---@field Overlay_Desc_Box UOverlay
---@field Text_ItemSlot UTextBlock
---@field WBP_UI_Inventory_ItemDescriptionBox UWBP_UI_Inventory_ItemDescriptionBox_C
---@field FocusedButton USBZMenuButton
UWBP_UI_ItemInventoryScreen_C = {}

function UWBP_UI_ItemInventoryScreen_C:OnItemSlotScreenDisplayed() end
---@param PreviousValue FName
function UWBP_UI_ItemInventoryScreen_C:OnGainedStackFocused(PreviousValue) end
function UWBP_UI_ItemInventoryScreen_C:OnLostStackFocused() end
---@param InActionInput FName
function UWBP_UI_ItemInventoryScreen_C:OnControlsReferenceClicked(InActionInput) end
---@param SelectedButton USBZMenuButton
---@param bIsFocused boolean
function UWBP_UI_ItemInventoryScreen_C:OnItemSlotButtonFocusedChanged(SelectedButton, bIsFocused) end
---@param SelectedButton USBZMenuButton
function UWBP_UI_ItemInventoryScreen_C:OnItemSlotButtonSelected(SelectedButton) end
---@param EntryPoint int32
function UWBP_UI_ItemInventoryScreen_C:ExecuteUbergraph_WBP_UI_ItemInventoryScreen(EntryPoint) end


