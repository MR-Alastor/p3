---@meta

---@class AMainMenu_BP_SignStreet_01_D_Stop_C : ABP_Tintable_Fixture_C
AMainMenu_BP_SignStreet_01_D_Stop_C = {}


