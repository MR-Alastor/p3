---@meta

---@class UBP_Order_LookAndComment_C : USBZAIOrder_LookAndComment
UBP_Order_LookAndComment_C = {}


