---@meta

---@class ABP_Suit_Customizable_C : AActor
---@field SK_SuitChainsPlaceholder00 USkeletalMeshComponent
---@field DefaultSceneRoot USceneComponent
ABP_Suit_Customizable_C = {}



