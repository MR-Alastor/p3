---@enum EGridlyColumnDataType
EGridlyColumnDataType = {
    String = 0,
    Number = 1,
    EGridlyColumnDataType_MAX = 2,
}

