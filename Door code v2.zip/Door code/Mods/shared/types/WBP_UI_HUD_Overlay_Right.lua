---@meta

---@class UWBP_UI_HUD_Overlay_Right_C : USBZHUDOverlayRight
---@field UberGraphFrame FPointerToUberGraphFrame
---@field Label_SecurityCompany UTextBlock
---@field Text_Difficulty UTextBlock
---@field Text_LevelName UTextBlock
---@field Text_SecurtyCompaniesList UTextBlock
UWBP_UI_HUD_Overlay_Right_C = {}

function UWBP_UI_HUD_Overlay_Right_C:SetHeistName() end
function UWBP_UI_HUD_Overlay_Right_C:SetSecurityCompaniesText() end
function UWBP_UI_HUD_Overlay_Right_C:SetDifficultyText() end
function UWBP_UI_HUD_Overlay_Right_C:OnInitialized() end
---@param EntryPoint int32
function UWBP_UI_HUD_Overlay_Right_C:ExecuteUbergraph_WBP_UI_HUD_Overlay_Right(EntryPoint) end


