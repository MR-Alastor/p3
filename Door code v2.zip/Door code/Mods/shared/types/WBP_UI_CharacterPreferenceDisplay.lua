---@meta

---@class UWBP_UI_CharacterPreferenceDisplay_C : USBZMainMenuInventoryCharacterPreferenceDisplay
---@field Widget_TabBackward UWBP_UI_Widget_ActionInput_Hold_C
---@field Widget_TabForward UWBP_UI_Widget_ActionInput_Hold_C
UWBP_UI_CharacterPreferenceDisplay_C = {}



