---@meta

---@class USettings_GroupTitle_C : UTextBlock
USettings_GroupTitle_C = {}


