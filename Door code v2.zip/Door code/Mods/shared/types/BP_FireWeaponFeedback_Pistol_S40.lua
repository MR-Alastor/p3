---@meta

---@class UBP_FireWeaponFeedback_Pistol_S40_C : USBZLocalPlayerFeedback
UBP_FireWeaponFeedback_Pistol_S40_C = {}


