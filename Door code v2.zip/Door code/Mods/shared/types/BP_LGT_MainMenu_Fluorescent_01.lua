---@meta

---@class ABP_LGT_MainMenu_Fluorescent_01_C : ABP_Master_Light_Fixture_C
---@field Cable UStaticMeshComponent
---@field RectLight URectLightComponent
---@field ['Cable Length'] float
ABP_LGT_MainMenu_Fluorescent_01_C = {}

function ABP_LGT_MainMenu_Fluorescent_01_C:UserConstructionScript() end


