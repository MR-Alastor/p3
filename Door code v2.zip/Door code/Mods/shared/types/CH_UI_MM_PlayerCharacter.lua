---@meta

---@class ACH_UI_MM_PlayerCharacter_C : ASBZMainMenuPlayerCharacter
ACH_UI_MM_PlayerCharacter_C = {}


