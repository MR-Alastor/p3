---@meta

---@class UWBP_UI_Challenge_PanelButton_C : USBZMainMenuBaseChallengeButton
---@field UberGraphFrame FPointerToUberGraphFrame
---@field Border UBorder
---@field Border_Highlight UBorder
---@field Image_ChallengeButtonBackground UImage
---@field Image_ChallengeButtonHighlight UImage
---@field Image_ChallengeComplete UImage
---@field Image_ChallengeLocked UImage
---@field Image_Icon UImage
---@field Image_RewardIcon UImage
---@field InvalidationBox_ChallengeButton UInvalidationBox
---@field ProgressBar_ChallengeProgress UProgressBar
---@field Root_Canvas UCanvasPanel
---@field Text_ChallengeDescription UTextBlock
---@field Text_ChallengeName UTextBlock
---@field Text_Progress UTextBlock
---@field TextBlock_RewardQuantity UTextBlock
---@field MaxValueToUse int32
---@field MinValueToUse int32
---@field InfamyIcon UPaperSprite
UWBP_UI_Challenge_PanelButton_C = {}

---@param bIsFocused boolean
function UWBP_UI_Challenge_PanelButton_C:SetFocusedVisuals(bIsFocused) end
---@param bIsHovered boolean
function UWBP_UI_Challenge_PanelButton_C:SetHoveredVisuals(bIsHovered) end
---@param Loaded UObject
function UWBP_UI_Challenge_PanelButton_C:OnLoaded_B5895D5248A51A4562096DB3E5E08E50(Loaded) end
---@param bInIsHovered boolean
function UWBP_UI_Challenge_PanelButton_C:ButtonHoveredChanged(bInIsHovered) end
---@param InChallengeData FSBZChallengeData
function UWBP_UI_Challenge_PanelButton_C:OnChallengeDataInititalized(InChallengeData) end
---@param bInHasFocus boolean
function UWBP_UI_Challenge_PanelButton_C:ButtonFocusedChanged(bInHasFocus) end
---@param IsDesignTime boolean
function UWBP_UI_Challenge_PanelButton_C:PreConstruct(IsDesignTime) end
function UWBP_UI_Challenge_PanelButton_C:OnInitialized() end
---@param EntryPoint int32
function UWBP_UI_Challenge_PanelButton_C:ExecuteUbergraph_WBP_UI_Challenge_PanelButton(EntryPoint) end


