---@meta

---@class UCS_FireWeapon_AssaultRifle_CAR4_C : UMatineeCameraShake
UCS_FireWeapon_AssaultRifle_CAR4_C = {}


