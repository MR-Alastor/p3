---@meta

---@class UGA_Fire_C : USBZPlayerFireRangedWeaponAbility
UGA_Fire_C = {}


