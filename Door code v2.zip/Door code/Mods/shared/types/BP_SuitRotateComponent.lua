---@meta

---@class UBP_SuitRotateComponent_C : USBZCustomizationRotateComponent
UBP_SuitRotateComponent_C = {}


