---@meta

---@class UWBP_MainMenu_Social_ReportPopup_C : USBZWidgetBase
---@field ReportCommentTextField UMultiLineEditableText
---@field ReportPlayerLabel UTextBlock
---@field TextBoxBackground UImage
UWBP_MainMenu_Social_ReportPopup_C = {}

---@param PlayerName FText
function UWBP_MainMenu_Social_ReportPopup_C:SetPlayerName(PlayerName) end


