---@meta

---@class UGA_PlaceItem_C : USBZPlaceItemAbility
UGA_PlaceItem_C = {}


