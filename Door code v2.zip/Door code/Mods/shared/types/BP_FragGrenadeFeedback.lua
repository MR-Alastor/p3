---@meta

---@class UBP_FragGrenadeFeedback_C : USBZLocalPlayerFeedback
UBP_FragGrenadeFeedback_C = {}


