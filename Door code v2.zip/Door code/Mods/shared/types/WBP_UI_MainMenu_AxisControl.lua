---@meta

---@class UWBP_UI_MainMenu_AxisControl_C : USBZControlsReferenceAxisWidget
---@field UberGraphFrame FPointerToUberGraphFrame
---@field Image_Background UImage
UWBP_UI_MainMenu_AxisControl_C = {}

---@param IsDesignTime boolean
function UWBP_UI_MainMenu_AxisControl_C:PreConstruct(IsDesignTime) end
function UWBP_UI_MainMenu_AxisControl_C:OnInitialized() end
---@param EntryPoint int32
function UWBP_UI_MainMenu_AxisControl_C:ExecuteUbergraph_WBP_UI_MainMenu_AxisControl(EntryPoint) end


