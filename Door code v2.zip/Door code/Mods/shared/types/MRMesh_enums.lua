---@enum EMeshTrackerVertexColorMode
EMeshTrackerVertexColorMode = {
    None = 0,
    Confidence = 1,
    Block = 2,
    EMeshTrackerVertexColorMode_MAX = 3,
}

