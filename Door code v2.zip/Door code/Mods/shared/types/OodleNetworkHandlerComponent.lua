---@meta

---@class UOodleNetworkTrainerCommandlet : UCommandlet
---@field bCompressionTest boolean
---@field HashTableSize int32
---@field DictionarySize int32
---@field DictionaryTrials int32
---@field TrialRandomness int32
---@field TrialGenerations int32
---@field bNoTrials boolean
UOodleNetworkTrainerCommandlet = {}



