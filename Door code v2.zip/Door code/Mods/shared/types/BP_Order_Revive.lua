---@meta

---@class UBP_Order_Revive_C : USBZAIOrder_Revive
---@field UberGraphFrame FPointerToUberGraphFrame
UBP_Order_Revive_C = {}

---@param Pawn APawn
function UBP_Order_Revive_C:OnStartedBP(Pawn) end
---@param EntryPoint int32
function UBP_Order_Revive_C:ExecuteUbergraph_BP_Order_Revive(EntryPoint) end


