---@meta

---@class FPlatformRuntimeAudioCompressionOverrides
---@field bOverrideCompressionTimes boolean
---@field DurationThreshold float
---@field MaxNumRandomBranches int32
---@field SoundCueQualityIndex int32
FPlatformRuntimeAudioCompressionOverrides = {}



