---@meta

---@class UCS_FireWeapon_Pistol_S40_C : UMatineeCameraShake
UCS_FireWeapon_Pistol_S40_C = {}


