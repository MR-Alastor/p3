---@meta

---@class UGE_Throwable_FragGrenade_C : UGameplayEffect
UGE_Throwable_FragGrenade_C = {}


