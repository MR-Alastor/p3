---@meta

---@class UBP_Order_Patrol_C : USBZAIOrder_Patrol
UBP_Order_Patrol_C = {}


