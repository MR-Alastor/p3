---@meta

---@class UAudioCurveSourceComponent : UAudioComponent
---@field CurveSourceBindingName FName
---@field CurveSyncOffset float
UAudioCurveSourceComponent = {}



