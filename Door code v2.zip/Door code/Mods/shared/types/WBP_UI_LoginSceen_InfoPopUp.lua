---@meta

---@class UWBP_UI_LoginSceen_InfoPopUp_C : USBZLoginScreenInfoPopupWidget
---@field UberGraphFrame FPointerToUberGraphFrame
---@field TextBlock_100 UTextBlock
UWBP_UI_LoginSceen_InfoPopUp_C = {}

function UWBP_UI_LoginSceen_InfoPopUp_C:OnInfoTextInitialized() end
---@param EntryPoint int32
function UWBP_UI_LoginSceen_InfoPopUp_C:ExecuteUbergraph_WBP_UI_LoginSceen_InfoPopUp(EntryPoint) end


