---@meta

---@class ABP_GameModeMainMenu_C : ASBZGameModeMainMenu
---@field DefaultSceneRoot USceneComponent
ABP_GameModeMainMenu_C = {}



