---@meta

---@class UBP_GlobalItemDatabase_C : USBZGlobalItemDatabase
UBP_GlobalItemDatabase_C = {}


